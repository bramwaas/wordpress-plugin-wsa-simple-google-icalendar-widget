<?php 
/*
 * version 2.0.0
 */
return array('dependencies' => array('wp-blocks', 'wp-element', 'wp-block-editor', 'wp-i18n', 'wp-server-side-render'  ), 'version' => '2.0.0' . filemtime( plugin_dir_path( __FILE__ ) . 'simple-ical-block.js'));
